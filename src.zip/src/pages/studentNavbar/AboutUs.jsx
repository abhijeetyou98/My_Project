import React from 'react'

function AboutUs2() {
  return (
    <div>
      <h1>yoo</h1>
    </div>
  )
}

export default AboutUs2