import React from "react";
import {Col,   Container,   Row }  from 'react-bootstrap';
import Box from '@mui/material/Box';
import VerticalLinearStepper from "../../components/student/VerticalLinearStepper";
import AcademicInfo from "../studentRegistration/AcademicInfo";

const Registration = () => {

  return (
    // here we used container so that there is some padding in left and right
  // inside row there are 12 grids which can be converted to columns 
  //  1 col= 12 grids , 2 cols = 6grid each n so on
  
  <></>
//   <Container style={{ display: 'flex', flexDirection: 'row', alignItems: 'flex-start' }}>
//   <Box sx={{
//     width: "470px",
//     height: "1080px",
//     background: "transparent linear-gradient(202deg, #A57548 0%, #755334E6 100%) 0% 0% no-repeat padding-box",
//     borderRadius: "40px 0px 0px 40px"
//   }}>
//     <VerticalLinearStepper />
//     </Box>

//   <Box sx={{ 
//     width:"970px",
//     height: "1080px", 
//     position:"relative",
//     background: "#FFFFFF 0% 0% no-repeat padding-box",
//     borderRadius: "0px 40px 40px 0px",
//     opacity:"0.9",
//     boxShadow: "0px 3px 9px #00000040" }}>

//   <AcademicInfo />
//   </Box>
// </Container>
       
 
  );
}

export default Registration
  