import React from 'react'

function SuccessStories() {
  return (
    <div>SuccessStories</div>
  )
}

export default SuccessStories