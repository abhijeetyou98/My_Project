import React from 'react'

function Contact2() {
  return (
    <div>Contact</div>
  )
}

export default Contact2