import React from 'react'

function NavigationBar() {
  return (
    <div>
      <h1>Navigation Bar</h1>
      </div>
  )
}

export default NavigationBar