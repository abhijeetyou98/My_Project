import React from 'react'

function Registration() {
  return (
    <div>Registration</div>
  )
}

export default Registration