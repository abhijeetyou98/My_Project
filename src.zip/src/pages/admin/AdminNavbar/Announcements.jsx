import React from 'react'

function Announcements() {
  return (
    <div>Announcements</div>
  )
}

export default Announcements