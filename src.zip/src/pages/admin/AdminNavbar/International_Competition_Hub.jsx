import React from 'react'

function InternationalCompetitionHub() {
  return (
    <div>International_competition_hub</div>
  )
}

export default InternationalCompetitionHub