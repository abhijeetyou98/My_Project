import React from 'react'

function SuccessStories() {
  return (
    <div>Success Stories</div>
  )
}

export default SuccessStories