import React from 'react'

function WhyUs() {
  return (
    <div>WhyUs</div>
  )
}

export default WhyUs