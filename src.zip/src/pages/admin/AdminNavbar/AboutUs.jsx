import React from 'react'

function AboutUs() {
  return (
    <div>About Us</div>
  )
}

export default AboutUs