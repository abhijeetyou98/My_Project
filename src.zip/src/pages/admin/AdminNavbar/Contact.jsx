import React from 'react'

function Contact() {
  return (
    <div>Contact Us</div>
  )
}

export default Contact;