import React from 'react'
import Header2 from '../../../components/admin/Header2'
import axios from "axios";
import {URL} from '../../../config'
import { useState, useEffect } from "react";
import { toast } from "react-toastify";

const AdminHome = () => {
  return (
    <div>
        

    </div>
  )
}

export default AdminHome