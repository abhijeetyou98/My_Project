import React from 'react'

function AcademicInfo() {
  return (
    <div>AcademicInfo</div>
  )
}

export default AcademicInfo