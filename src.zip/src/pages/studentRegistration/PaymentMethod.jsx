import React from 'react'

const PaymentMethod = () => {
  return (
    <div>PaymentMethod</div>
  )
}

export default PaymentMethod