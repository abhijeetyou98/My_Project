import React from 'react'

const InvoiceBill = () => {
  return (
    <div>InvoiceBill</div>
  )
}

export default InvoiceBill