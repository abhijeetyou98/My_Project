import React from 'react'

function Layout() {
  return (
    <div>Layout</div>
  )
}

export default Layout