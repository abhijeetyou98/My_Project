export const MenuItems = [
    {
      title: 'Personalised /Group Facilitation',
      path: '/personalised',
      cName: 'dropdown-link'
    },
    {
      title: 'International Competition Hub',
      path: '/international',
      cName: 'dropdown-link'
    },
    {
      title: 'Bridge The Gap Program',
      path: '/bridge',
      cName: 'dropdown-link'
    }
   
  ];
  